# vanilla-template

This is a template for weekly assignments.
